# webglserver
Basic NodeJS Server in Java Script for Unity WebGL Aplication

WEBGL ROOMS MULTIPLAYER TEMPLATE (HTML5)

this Server is ready for multiplayer online games with player created rooms in html5. 
Features:
* WebGL Template
* WebGL Game Demo
* Unity UI for multiplayer menus example
* Check my website for more: https://danielboldrin.azurewebsites.net/

About unity WebGL server/client
 - Easy to send and receive messages from a nodeJS server
 - Complete example scene.
 - Optimized Code for performance and game smoothness (C#).
 - Script documentation.
 - Easy to deploy the game in any cloud service